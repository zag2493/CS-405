#include <gtest/gtest.h>
#include <cstdint>
#include <limits>
#include "pch.h"

// Test fixture for integer overflow tests
class IntegerOverflowTest : public ::testing::Test
{
protected:
    // Initialize variables for testing
    int32_t max_int32 = std::numeric_limits<int32_t>::max();
    int32_t min_int32 = std::numeric_limits<int32_t>::min();

    void SetUp() override
    {
        // No specific setup needed, but can initialize variables if required
    }

    void TearDown() override
    {
        // No cleanup needed
    }

    // Helper function to safely add integers with overflow check
    bool safe_add(int32_t a, int32_t b, int32_t& result)
    {
        if (b > 0 && a > max_int32 - b) return false; // Overflow
        if (b < 0 && a < min_int32 - b) return false; // Underflow
        result = a + b;
        return true;
    }
};

// Positive Test: Safe addition within bounds
TEST_F(IntegerOverflowTest, SafeAdditionWithinBounds)
{
    int32_t a = 100;
    int32_t b = 200;
    int32_t result;
    ASSERT_TRUE(safe_add(a, b, result));
    EXPECT_EQ(result, 300);
}

// Positive Test: Safe addition near max boundary
TEST_F(IntegerOverflowTest, SafeAdditionNearMax)
{
    int32_t a = max_int32 - 10;
    int32_t b = 5;
    int32_t result;
    ASSERT_TRUE(safe_add(a, b, result));
    EXPECT_EQ(result, max_int32 - 5);
}

// Negative Test: Detect overflow when adding large numbers
TEST_F(IntegerOverflowTest, DetectOverflowOnLargeAddition)
{
    int32_t a = max_int32;
    int32_t b = 1;
    int32_t result;
    EXPECT_FALSE(safe_add(a, b, result));
}

// Negative Test: Detect underflow when subtracting large negative
TEST_F(IntegerOverflowTest, DetectUnderflowOnLargeSubtraction)
{
    int32_t a = min_int32;
    int32_t b = -1;
    int32_t result;
    EXPECT_FALSE(safe_add(a, b, result));
}

// Positive Test: Safe subtraction within bounds
TEST_F(IntegerOverflowTest, SafeSubtractionWithinBounds)
{
    int32_t a = 300;
    int32_t b = -100;
    int32_t result;
    ASSERT_TRUE(safe_add(a, b, result));
    EXPECT_EQ(result, 200);
}

// Negative Test: Noncompliant code causes overflow
TEST_F(IntegerOverflowTest, NoncompliantCodeOverflow)
{
    int32_t a = max_int32;
    int32_t b = 1;
    // Simulate noncompliant code without bounds checking
    EXPECT_THROW({
        int32_t result = a + b; // Overflow, undefined behavior
        (void)result; // Suppress unused variable warning
        }, std::overflow_error); // Note: C++ doesn't throw by default; this is for demonstration
}