// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

//Create custom exception class 
class CustomException : public std::exception {
public:
    CustomException(const std::string& message) : msg(message) {}
    const char* what() const noexcept override {
        return msg.c_str();
    }
private:
    std::string msg;
};

//New function to test catch(...)
void do_unexpected_exception_test()
{
    //Throw an int to get unexpected exception type
    throw 42; //Should not be caught with other exceptions
    std::cout << "This line should not be reached." << std::endl;
}

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    
    //Throw standard runtime_error exception
    throw std::runtime_error("Error in even more custom application logic");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    try {
        std::cout << "Running Custom Application Logic." << std::endl;

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    catch (const std::exception& e) {
        //Catch and display exception message
        std::cerr << "Standard exception caught in Do Custom Application Logic: " << e.what() << std::endl;
    }

    //Throw custom exception
    throw CustomException("Custom application failed");

    //shouldnt reach 
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    
    //check for division by zero and throw standard exception
    if (den == 0.0f) {
        throw std::runtime_error("Division by zero error");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    
    //Try-Catch block for division
    try {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& e) {
        //Handle division runtime_error
        std::cerr << "Division error caught: " << e.what() << std::endl;
    }
}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        //Call test for catch(...)
        //do_unexpected_exception_test();
        do_custom_application_logic();

       
    }
    // TODO: Create exception handlers that catch (in this order):
    
    //  your custom exception
    catch (const CustomException& e) {
        //Handle custom exception
        std::cerr << "Custom exception caught: " << e.what() << std::endl;
    }

    //  std::exception
    catch (const std::exception& e) {
        //Handle standard exception
        std::cerr << "Standard exception caught in main: " << e.what() << std::endl;
    }

    //  uncaught exception 
    catch (...) {
        //Handle any unexpected exceptions
        std::cerr << "Unknown exception caught in main" << std::endl;
    }
    //  that wraps the whole main function, and displays a message to the console.

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu